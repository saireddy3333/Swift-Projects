//
//  Transaction.swift
//  ATM Machine
//
//  Created by Kongari, Sai Shiva Reddy on 6/29/22.
//

import UIKit

class Transaction {

}
